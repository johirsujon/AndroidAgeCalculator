package me.johir.www.test;

import android.app.DatePickerDialog;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.Calendar;
import java.util.Date;
import java.time.format.DateTimeFormatter;

public class MainActivity extends AppCompatActivity {



    TextView resultTextView, dateTextView;
    Button calculateButton;
    LocalDate birthDate, currentDate;
    Calendar calendar;
    DatePickerDialog.OnDateSetListener date;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        calculateButton = findViewById(R.id.calculateButton);
        resultTextView = findViewById(R.id.resultTextView);
        dateTextView = findViewById(R.id.dateTexView);

        calendar = Calendar.getInstance();


        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                long curent = calendar.getTimeInMillis();
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                long selected = calendar.getTimeInMillis();

                String dateFormat = "yyyy-MM-dd";
                SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
                try{
                    dateTextView.setText(sdf.format(calendar.getTime()));
                }catch (Exception e){}

                if(selected>curent)
                {
                    resultTextView.setText("Birthday cann't be future date");
                    calculateButton.setEnabled(false);
                }
                else {
                    resultTextView.setText("Press Calcualte Button To calculate");
                    calculateButton.setEnabled(true);
                }

            }

        }; //DatepickeDialog.ondatsetListener date end


        dateTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(MainActivity.this, date, calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });



        calculateButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {

                try{




               String str = dateTextView.getText().toString();
                String dateFormat = "yyyy-MM-dd";
                DateFormat sdf = new SimpleDateFormat(dateFormat);
               Date date=null;
                try {
                    date = sdf.parse(str);
                } catch (Exception e) {
                 str = "Select birthday!!";

                }
                Date today = new Date();
                //String temp = sdf.format(today);
                //try {
                  //  today = sdf.parse(temp);
                //} catch (ParseException e) {}

                int birthYear = date.getYear();
                birthYear+=1900;
                int birthMonth = date.getMonth();
                birthMonth+=1;
                int birthDay = date.getDate();


                int currentYear = today.getYear();
                currentYear+=1900;
                int currentMonth = today.getMonth();
                currentMonth+=1;

                int currentDay = today.getDate();


                int resDay=0,resMonth=0,resYear=0;




                if(currentDay>=birthDay){
                    resDay = currentDay-birthDay;
                }
                else{
                    resDay = currentDay-birthDay+30;
                    currentMonth-=1;
                    if(currentMonth==0){currentMonth = 12;currentYear-=1;}
                }

                if(currentMonth>=birthMonth){
                    resMonth = currentMonth-birthMonth;
                }else{
                   resMonth = currentMonth-birthMonth+12;
                   currentYear-=1;
                }
                if(currentYear>=birthYear){
                    resYear = currentYear-birthYear;
                }




                String strRes = String.valueOf(resYear)+" Year ,"+String.valueOf(resMonth)+" Month, "+String.valueOf(resDay)+" Day";
               // String strRes = temp;
                resultTextView.setText("Your Age is:\n "+strRes);
                }catch (Exception e){resultTextView.setText("Select Date");}

            }
        });



    }


}
